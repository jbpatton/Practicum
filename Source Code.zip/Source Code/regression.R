#Multiple Linear Regression

dataset = read.csv('final_leads.csv')
dataset = dataset[,6:20]

library(caTools)
set.seed(123456789)
split = sample.split(dataset$client, SplitRatio = 0.75)
training_set = subset(dataset, split == TRUE)
test_set = subset(dataset, split == FALSE)

#Fitting MLR to Training
regressor = lm(formula = client ~ .,
               data = training_set)

#Predictions
y_pred = predict(regressor, newdata = test_set)
y_pred


#Removing all high p-value from regressor
regressor1 = lm(formula = client ~ time_to_contact_hrs+total_attempts+total_connects+connected_mgrs
               +talk_duration_min+conn_90+conn_240+conn_mgr_90+conn_mgr_240,
               data = test_set)

summary(regressor1)
summary(resid(regressor1))

reg3 = lm(formula = client ~ connected_mgrs + conn_90 + talk_duration_min,
          data = test_set)

head(test_set)
round(cor(test_set),3)
library(car)
alias(regressor)
vif(regressor1)
mean(vif(regressor1))

test = data.frame(scale(training_set))

#Breaking out Training & Test Sets
trainx = training_set[,-15] 
testx = test_set[,-15]

#Scale and fit data for model
trainx.pca <- prcomp(trainx, center = TRUE, scale = TRUE)
testx.pca <- prcomp(testx,center = TRUE, scale = TRUE)

train.pca = cbind(training_set[,15],data.frame(trainx.pca$x))
colnames(train.pca)[1] <- "Client"

test.pca = cbind(test_set[,15],data.frame(testx.pca$x))
colnames(test.pca)[1] <- "Client"

#First PCA Run w/ All variables
pcr1 <- lm(Client~., data = test.pca)
summary(pcr1)

#Updated with 1st Results
pcr2 <- lm(Client~PC1+PC2+PC5+PC6+PC7+PC8+PC9+PC11, data = test.pca)
summary(pcr2)

#plot(pcr3, pch=12, col="blue")

prob_pred= predict(pcr3, newdata = test.pca[-1])
prob_pred


quantile(prob_pred, c(.2,.4,.5,.6,.8))
y_pred = (ifelse(prob_pred > 0.07,1,0))

cm = table(test_set[,15],y_pred)
cm

#Logistic Regression
pcr4 <- glm(Client~PC1+PC2+PC4+PC5+PC6+PC7+PC8+PC9+PC11, family = binomial(), data = train.pca)
prob_pred= predict(pcr4, newdata = test.pca[-1])
quantile(prob_pred, c(.2,.4,.5,.6,.8))
y_pred1 = (ifelse(prob_pred > -3.3,1,0))
cm1 = table(test_set[,15],y_pred1)
cm1

