#Artificial Neural Network

dataset = read.csv('final_leads_ann.csv')
dataset = dataset[2:15]

#Encoding categorical as factors
dataset$source = as.numeric(factor(dataset$source,
                                   levels = c('Form','Phone'),
                                   labels = c(1,2)))
dataset$district = as.numeric(factor(dataset$district,
                                     levels = c('East','West','Central','Other'),
                                     labels = c(1,2,3,4)))
dataset$device = as.numeric(factor(dataset$device,
                                   levels = c('mobile','desktop','tablet'),
                                   labels = c(1,2,3)))
dataset$regional_director = as.numeric(factor(dataset$regional_director,
                                              levels = c('Kara Speer', 'Kellie Bishop','Steven Vernor','Julie Schreckenberg','Cody Olson','Michael Barker','Joshua Schwartz','Aftynn Peters'),
                                              labels = c(1,2,3,4,5,6,7,8)))

library(caTools)
set.seed(123456789)
split = sample.split(dataset$client, SplitRatio = 0.75)
training_set = subset(dataset, split == TRUE)
test_set = subset(dataset, split == FALSE)

#Feature Scaling
training_set[-14] = scale(training_set[-14])
test_set[-14] = scale(test_set[-14])

#Fitting ANN to Training Set
library(h2o)
h2o.init(nthreads = -1)
classifier = h2o.deeplearning(y = 'client',
                              model_id = 'classifier',
                              training_frame = as.h2o(training_set),
                              validation_frame = as.h2o(test_set),
                              nfolds = 10,
                              keep_cross_validation_fold_assignment = TRUE,
                              fold_assignment = 'Stratified',
                              activation = 'Rectifier',
                              score_each_iteration = TRUE,
                              hidden = c(7,7),
                              epochs = 100,
                              train_samples_per_iteration = -2)

#Predictions on Test Set
prob_pred = h2o.predict(classifier, newdata = as.h2o(test_set[-14]))
quantile(prob_pred, c(.2,.4,.5,.6,.8))
y_pred = (prob_pred > 0.034)
y_pred = as.vector(y_pred)

#Confusion Matrix
cm = table(test_set[,14],y_pred)
cm

h2o.shutdown()

y_pred = (prob_pred > 0.5)
y_pred = as.vector(y_pred)

#Plotting Confusion & Metrics
#install.packages("e1071")
library(e1071)
library(caret)
cm1 <- confusionMatrix(data = test_set[,14], reference = y_pred)

draw_confusion_matrix <- function(cm) {
  
  layout(matrix(c(1,1,2)))
  par(mar=c(2,2,2,2))
  plot(c(100, 345), c(300, 450), type = "n", xlab="", ylab="", xaxt='n', yaxt='n')
  title('ANN: CONFUSION MATRIX', cex.main=2)
  
  # create the matrix 
  rect(150, 430, 240, 370, col='#3F97D0')
  text(195, 435, '0', cex=1.2)
  rect(250, 430, 340, 370, col='#F7AD50')
  text(295, 435, '1', cex=1.2)
  text(125, 370, 'Actual', cex=1.3, srt=90, font=2)
  text(245, 450, 'Predicted', cex=1.3, font=2)
  rect(150, 305, 240, 365, col='#F7AD50')
  rect(250, 305, 340, 365, col='#3F97D0')
  text(140, 400, '0', cex=1.2, srt=90)
  text(140, 335, '1', cex=1.2, srt=90)
  
  # add in the cm results 
  res <- as.numeric(cm1$table)
  text(195, 400, res[1], cex=1.6, font=2, col='white')
  text(195, 335, res[2], cex=1.6, font=2, col='white')
  text(295, 400, res[3], cex=1.6, font=2, col='white')
  text(295, 335, res[4], cex=1.6, font=2, col='white')
  
  # add in the specifics 
 ## plot(c(100, 0), c(100, 0), type = "n", xlab="", ylab="", main = "DETAILS", xaxt='n', yaxt='n')
 ## text(10, 85, names(cm1$byClass[1]), cex=1.2, font=2)
 # text(10, 70, round(as.numeric(cm1$byClass[1]), 3), cex=1.2)
 # text(30, 85, names(cm1$byClass[2]), cex=1.2, font=2)
  #text(30, 70, round(as.numeric(cm1$byClass[2]), 3), cex=1.2)
  #text(50, 85, names(cm1$byClass[5]), cex=1.2, font=2)
  #text(50, 70, round(as.numeric(cm1$byClass[5]), 3), cex=1.2)
  #text(70, 85, names(cm1$byClass[6]), cex=1.2, font=2)
  #text(70, 70, round(as.numeric(cm1$byClass[6]), 3), cex=1.2)
  #text(90, 85, names(cm1$byClass[7]), cex=1.2, font=2)
  #text(90, 70, round(as.numeric(cm1$byClass[7]), 3), cex=1.2)
  
  # add in the accuracy information 
  #text(30, 35, names(cm1$overall[1]), cex=1.5, font=2)
  #text(30, 20, round(as.numeric(cm1$overall[1]), 3), cex=1.4)
  #text(70, 35, names(cm1$overall[2]), cex=1.5, font=2)
  #text(70, 20, round(as.numeric(cm1$overall[2]), 3), cex=1.4)
}  

draw_confusion_matrix(cm1)

summary(classifier)
